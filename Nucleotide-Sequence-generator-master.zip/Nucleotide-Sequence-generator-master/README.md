# Nucleotide-Sequence-generator

Website  Link : https://nucleotide-generator.herokuapp.com/

This project is to generate random sequence of DNA nucleotides (i.e. A, G, T, C) and also to find reverse complement of that particular sequence.

This project is made out of flask and **if you love to contribute please make a new issue and let me know.**

## Website Preview

<p align="center">
        <img src="https://i.imgur.com/M8rcczr.png" title="Nucleotide seq generator">
</p>

### This Project was made with help of these contributors

<p align="center">
        <a href="https://github.com/logan1x/Nucleotide-Sequence-generator/graphs/contributors">
                <img src="https://contributors-img.web.app/image?repo=logan1x/Nucleotide-Sequence-generator" />
        </a>
</p>
